
package ejemplos.ejemplo1interfaces;

/**
 *
 * @author cic
 */
public interface GrupoInterfaces extends Interface1, Interface2{
    final double x=34;
    public void hagoAlgo(int y);
    public void hagoAlgoMas(String s);
    
    
}
