
package ejemplos.ejemplo1interfaces;

/**
 *
 * @author cic
 */
public interface Interface1 {
    public void imprime();
}
