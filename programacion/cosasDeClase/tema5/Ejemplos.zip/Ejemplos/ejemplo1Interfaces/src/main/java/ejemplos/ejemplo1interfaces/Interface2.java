
package ejemplos.ejemplo1interfaces;

/**
 *
 * @author cic
 */
public interface Interface2 {
    public void mostrar();
}
