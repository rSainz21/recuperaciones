package ejemplos.estatico2;

/**
 *
 * @author cic
 */
public class Clase implements Interfaz {

    @Override
    public void metodo() {
        System.out.println("método en Clase");
    }

}
