/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen5.sistemadegestiondetiendamusica;
import java.time.LocalDate;
/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class Venta {
    private Album album;
    private Cliente cliente;
    private String fechaVenta;
    private String fechaDevolucion;
     //es null si aun no se a devuelto el album.

    public Venta(Album album, Cliente cliente,String fechaVenta ) {
        this.album = album;
        this.cliente = cliente;
        this.fechaVenta = fechaVenta;
    }

    public Album getAlbum() {
        return album;
    }

    public Cliente getCliente() {
        return cliente;
    }

  
    

    @Override
    public String toString() {
        return "Venta{" + "album=" + album + ", cliente=" + cliente + ", fechaVenta=" + fechaVenta + ", fechaDevolucion=" + fechaDevolucion + '}';
    }
    
    
}
