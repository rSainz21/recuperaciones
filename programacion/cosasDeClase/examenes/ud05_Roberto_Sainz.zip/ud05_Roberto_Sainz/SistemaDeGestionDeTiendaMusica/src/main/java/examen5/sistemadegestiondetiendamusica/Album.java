/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen5.sistemadegestiondetiendamusica;

import java.util.Scanner;

/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class Album implements Identificable {

    protected String titulo;
    protected String artista;

    public Album() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el titulo");
        this.titulo = scanner.nextLine();
        System.out.println("Introduce el artista");
        this.artista = scanner.nextLine();
    }

    public Album(String titulo, String artista) {
        this.titulo = titulo;
        this.artista = artista;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    @Override
    public String toString() {
        return "Album{" + "titulo=" + titulo + ", artista=" + artista + '}';
    }

    @Override
    public void imprime() {
    }

}
