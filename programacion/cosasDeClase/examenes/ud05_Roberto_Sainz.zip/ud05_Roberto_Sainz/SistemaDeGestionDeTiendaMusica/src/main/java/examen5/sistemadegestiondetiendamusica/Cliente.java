/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen5.sistemadegestiondetiendamusica;

import java.util.Scanner;

/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class Cliente {
    private String nombre;
    private String apellidos;

    public Cliente() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduce el nombre del cliente");
        this.nombre = scanner.nextLine();
        System.out.println("Introduce los apellidos");
        this.apellidos = scanner.nextLine();
    }

    public Cliente(String nombre, String apellidos) {
        this.nombre = nombre;
        this.apellidos = apellidos;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    @Override
    public String toString() {
        return "Cliente{" + "nombre=" + nombre + ", apellidos=" + apellidos + '}';
    }
    
    
    
    
}
