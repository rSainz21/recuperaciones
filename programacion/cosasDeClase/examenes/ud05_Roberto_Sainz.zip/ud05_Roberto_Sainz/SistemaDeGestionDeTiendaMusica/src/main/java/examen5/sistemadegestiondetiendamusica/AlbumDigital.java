/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen5.sistemadegestiondetiendamusica;

import java.util.Scanner;

/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class AlbumDigital extends Album {
    private float tamanoMB;

    public AlbumDigital() {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Introduce el tamano del album en MB");
        this.tamanoMB=scanner.nextInt();
    }

    public AlbumDigital(String titulo, String artista, float tamanoMB) {
        super(titulo, artista);
        this.tamanoMB = tamanoMB;
    }

    public float getTamanoMB() {
        return tamanoMB;
    }

    @Override
    public String toString() {
        return "AlbumDigital{" + "tamanoMB=" + tamanoMB + '}';
    }
    
    
    
    
}
