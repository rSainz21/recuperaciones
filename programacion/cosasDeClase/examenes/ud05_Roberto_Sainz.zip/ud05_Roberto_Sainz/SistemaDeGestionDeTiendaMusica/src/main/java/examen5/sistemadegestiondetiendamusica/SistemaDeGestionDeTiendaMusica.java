/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package examen5.sistemadegestiondetiendamusica;

/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class SistemaDeGestionDeTiendaMusica {

    public static void main(String[] args) {
        TiendaMusica tienda1=new TiendaMusica("TiendaMusica+DAMxx",5);
        Album album1=new Album();
        Cliente cliente1=new Cliente();
        AlbumDigital album2=new AlbumDigital("Back in Black","ACDC",80);
        AlbumFisico album3=new AlbumFisico("The Dark Side of the Moon","Pink Floyd",10);
        Cliente cliente2=new Cliente("Maria","Gonzalez");
        Cliente cliente3=new Cliente("Ignacio","Alvarez");
        tienda1.agregarAlbum(album1);
        tienda1.agregarClientes(cliente3);
        tienda1.toString();
      
                
        
        
    }
}
