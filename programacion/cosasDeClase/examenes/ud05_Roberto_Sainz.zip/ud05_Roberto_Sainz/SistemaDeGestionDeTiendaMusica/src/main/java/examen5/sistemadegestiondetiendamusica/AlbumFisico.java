/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen5.sistemadegestiondetiendamusica;

import java.util.Scanner;

/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class AlbumFisico extends Album {
    int numeroCanciones;

    public AlbumFisico() {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Introduce el numero de canciones");
        this.numeroCanciones=scanner.nextInt();
    }

    public AlbumFisico(String titulo, String artista, int numeroCanciones) {
        super(titulo, artista);
        this.numeroCanciones = numeroCanciones;
    }

    public int getNumeroCanciones() {
        return numeroCanciones;
    }

    @Override
    public String toString() {
        return "AlbumFisico{" + "numeroCanciones=" + numeroCanciones + '}';
    }
    
    

    
    
    
}
