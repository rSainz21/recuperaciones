/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen5.sistemadegestiondetiendamusica;

/**
 *
 * @author DAM1//RobertoSainzArjona
 */
public class TiendaMusica implements Identificable{
    
    private String nombreTienda;
    private Album [] albumes;
    private int nuAlbumes;
    private Cliente [] clientes;
    private Venta[] ventas;
    final int capacidadMax;

    public TiendaMusica(String nombreTienda, int capacidadMax) {
        this.nombreTienda = nombreTienda;
        this.albumes=new Album[capacidadMax];
        this.clientes=new Cliente[capacidadMax];
        this.ventas=new Venta[capacidadMax];
        this.capacidadMax=capacidadMax;
        
        
        
        
        
    }
    
    public boolean agregarAlbum(Album album){
        boolean agregarA;
        if(albumes.length>=capacidadMax){
            System.out.println("El album no ha sido agregado a la tienda");
            agregarA=false;   
        }else{
            for(int i=0;i<albumes.length;i++){
                if(albumes[i]==null){
                    albumes[i]=album;
                    
                    
                }
            }
            System.out.println("Se ha agregado el album");
            nuAlbumes++;
            agregarA=true;
        }
        return agregarA;
        
    }
    
    public boolean agregarClientes(Cliente cliente){
        boolean agregarC;
        if(clientes.length>=capacidadMax){
            System.out.println("El cliente no ha sido agregado a la tienda");
            agregarC=false;   
        }else{
            for(int i=0;i<clientes.length;i++){
                if(clientes[i]==null){
                    clientes[i]=cliente;
                    
                    
                }
            }
            
            System.out.println("Se ha agregado el cliente");
            agregarC=true;
        }
        return agregarC;
    }
    
    public boolean agregarVentas(Venta venta){
        boolean agregarV;
        if(ventas.length>=capacidadMax){
            System.out.println("La venta no ha sido agregada");
            agregarV=false;   
        }else{
            for(int i=0;i<ventas.length;i++){
                if(ventas[i]==null){
                    ventas[i]=venta;
                    
                    
                }
            }
            
            System.out.println("Se ha agregado la venta");
            agregarV=true;
        }
        return agregarV;
    }
    
    public boolean verCliente(Cliente cliente){
        if(cliente.equals(cliente)){
            System.out.println("El cliente esta en la tienda");
        }
        return false;
        
    }
    
    public boolean verAlbum(Album album){
        boolean albumEnTienda;
        if(album instanceof Album){
            albumEnTienda=true;
        }else{
            albumEnTienda=false;
        }
        return albumEnTienda;
        
    }
       
    
        
    
    public void venderAlbum(Album album, Cliente cliente){
        
    }
    
    
    
    
    @Override
    public void imprime() {
    }

    @Override
    public String toString() {
        return "TiendaMusica{" + "nombreTienda=" + nombreTienda + ", albumes=" + albumes + ", nuAlbumes=" + nuAlbumes + ", clientes=" + clientes + ", ventas=" + ventas + ", capacidadMax=" + capacidadMax + '}';
    }
    
    
    
}
