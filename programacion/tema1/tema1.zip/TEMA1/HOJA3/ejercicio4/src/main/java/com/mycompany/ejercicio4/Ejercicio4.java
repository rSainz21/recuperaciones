/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ejercicio4;

import java.util.Scanner;

/**
 *
 * @author dam1
 */
public class Ejercicio4 {

    public static void main(String[] args) {
        Scanner teclado;
        int a= new Scanner(System.in).nextInt();
        int b= new Scanner(System.in).nextInt();
        int c= new Scanner(System.in).nextInt();
        int x= new Scanner(System.in).nextInt();
        int y= a*x*x +b*+c;
        System.out.println("y es igual a "+y);
        
        
    }
}
