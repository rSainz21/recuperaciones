/*
 */
package ejemplo06.ejemplo07.lambda2;

/**
 * Segunda Interface funcional con String
 * @author cic
 */
public interface Funcion2 {
    public abstract void info(String mensaje);
}
