/*
 */
package ejemplo06.ejemplo07.lambda2;

/**
 *Primera interface funcional
 * @author cic
 */
public interface Funcion1 {
    public abstract int operacion(int a, int b);
}
