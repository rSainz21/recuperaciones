/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tema3.ejercicio3hoja5tema3;
import java.util.Scanner;
/**
 *
 * @author dam1
 */
public class Ejercicio3Hoja5tema3 {

    public static void main(String[] args) {
        Scanner t= new Scanner(System.in);
        System.out.println("Introduce la hora: ");
        
    }
}
