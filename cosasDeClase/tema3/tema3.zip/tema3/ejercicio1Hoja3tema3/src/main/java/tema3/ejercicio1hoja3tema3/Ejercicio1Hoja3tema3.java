/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tema3.ejercicio1hoja3tema3;

/**
 *
 * @author dam1
 */
public class Ejercicio1Hoja3tema3 {

    public static void main(String[] args) {
        Fondo Fondo1 = new Fondo(1000.0, 5.0, 10);
       
        Fondo1.evolucion();
    }
}
