/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tema3.ejercicio1hoja1;
import java.util.Scanner;
/**
 *
 * @author dam1
 */
public class Ejercicio1Hoja1 {

    public static void main(String[] args) {
        calculo calculo=new calculo();
        calculo.metodo1();
        calculo.metodo2();
        calculo.metodo3();
        calculo.metodo4();
        calculo.metodo5();
        calculo.metodo6();
        calculo.metodo7();
        calculo.metodo8();
    }
}
