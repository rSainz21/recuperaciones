/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tema3.ejercicio2hoja1;

/**
 *
 * @author dam1
 */
public class Ejercicio2Hoja1 {

    public static void main(String[] args) {
        Ticket ticket = new Ticket(12.5); // Ejemplo con 12.5 kilos vendidos
        System.out.println(ticket.imprimir());
    }
}
