/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tema3.ejercicio4hoja2tema3;

/**
 *
 * @author dam1
 */
public class Ejercicio4Hoja2tema3 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
