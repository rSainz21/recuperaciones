/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package tema4.ejercicio1hoja3tema4;

/**
 *
 * @author dam1
 */
public class Ejercicio1Hoja3Tema4 {

    public static void main(String[] args) {
        Triatlon atleta = new Triatlon(13, "Juan", 5);
        
        System.out.println("¿Es seleccionado? " + atleta.esSeleccionado());
    }
}



