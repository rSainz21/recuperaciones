/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package examen2.ejercicio1tema3;

import java.util.Scanner;

/**
 *
 * @author DAM1
 */
public class MaquinaExpendedora {
    private double costoProducto;
    private double saldo;
    
    public MaquinaExpendedora(double costoProducto, double saldo){
    this.costoProducto=costoProducto;
    this.saldo=saldo;
    }
    
    public double getCostoProducto(){
        return costoProducto;
    }
    
    public void setCostoProducto(){
        this.costoProducto=costoProducto;
        
    }
    
    public double getSaldo(){
        return saldo;
    }
    
    public void setSaldo(){
        this.saldo=saldo;
    }
    
    public void restarSaldo(double cantidad){
        if(cantidad>0){
            saldo-=cantidad;
        }
    }
    
    public void recargarSaldo(double cantidad){
        Scanner teclado=new Scanner(System.in);
        System.out.println("Introduce la cantidad a incrementar");
        cantidad=teclado.nextDouble();
        if(cantidad>0){
            saldo+=cantidad;
            System.out.println("Se a incrementado "+cantidad+"€ a tu saldo");
        }else{
            System.out.println("La operacion no ha sido realizada");
        }
        
    }
   
}
