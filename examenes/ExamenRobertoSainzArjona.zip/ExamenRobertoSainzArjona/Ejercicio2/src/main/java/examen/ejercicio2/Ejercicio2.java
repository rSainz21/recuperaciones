/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package examen.ejercicio2;
import java.time.LocalDate;
/**
 *
 * @author DAM1
 */
public class Ejercicio2 {//Roberto Sainz Arjona DAM1090=

    public static void main(String[] args) {
        Taller taller1=new Taller(20);
        
        taller1.agregarCoche();
        taller1.mostrarTaller();
        
    }
}
